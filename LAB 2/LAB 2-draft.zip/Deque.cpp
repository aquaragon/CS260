//
// Created by Aiden on 4/12/2022.
//

#include "Deque.hpp"
#include <stdexcept>

using std::out_of_range, std::string, std::to_string;

Deque::Deque(int n)
{
    if(n < MIN_SIZE)
    {
        array_size = DEFAULT_SIZE;
        this->deque_array = new int [array_size];
    }else
    {
        array_size = n;
        this->deque_array = new int [array_size];
    }
}

Deque::~Deque()
{
    delete [] deque_array;
}

void Deque::addTail(int value)
{
    if(count >= array_size)
    {
        resize();
    }
    count++; //Switch this
    deque_array[tail] = value;
    tail++;
    if (tail >= array_size)
    {
        tail = 0;
    }
}

void Deque::resize()
{
    int * doubled_array = new int [array_size * 2];
    for(int i = 0; i < count - 1; i++)
    {
        doubled_array[i] = deque_array[head];
        if(head == (array_size - 1))
        {
            head = 0;
        }else
        {
            head++;
        }

    }
    tail = count;
    head = 0; // may need to change
    array_size *= 2;
    delete [] deque_array;
    deque_array = doubled_array;
}

int Deque::removeHead() {
    if (count <= 0) {
        throw out_of_range("Queue is empty - removeHead");
    }
    count--; //switch this
    head++;
    if(head == (array_size - 1))
    {
        head = -1;
    }
    return deque_array[head];
}

bool Deque::isEmpty()
{
    bool empty = false;
    if(count <= 0 )
    {
        empty = true;
    }
    return empty;
}

string Deque::dumpArray()
{
    string dumped_array;
    for(int i = 0; i < array_size; i++)
    {

        if(i == (array_size - 1))
        {
            dumped_array += to_string(deque_array[i]);
        }else
        {
            dumped_array += to_string(deque_array[i]) + " ";
        }
    }


    return dumped_array;
}

string Deque::listQueue()
{
    string list_queue;
    int temp_track = head;
    while(temp_track != (tail - 1))
    {
        temp_track++;
        if(temp_track == (tail - 1))
        {
            list_queue += to_string(deque_array[temp_track]);
        }else
        {
            list_queue += to_string(deque_array[temp_track]) + " ";
        }
        if(temp_track == (array_size - 1))
        {
            temp_track = -1;
        }
    }
    return list_queue;
}

void Deque::addHead(int value)
{
    if(count >= array_size)
    {
        resize();
    }
    count++;
    deque_array[head] = value;
    head--;
}

int Deque::removeTail()
{
    if (count <= 0) {
        throw out_of_range("Queue is empty - removeTail");
    }
    count--; //switch this
    tail--;
    if(tail == 0)
    {
        tail = array_size;
    }
    return deque_array[tail];
}