//
// Created by aiden on 4/14/2022.
//


#include "TextClass.hpp"
#include <stdexcept>
#include <string>

using std::out_of_range, std::to_string;

Link::Link(char value, Link * next, Link * prev)
{
    this->value = value;
    this->next = next;
    this->prev = prev;
}

char Link::getValue()
{
    return this->value;
}

Link * Link::getNext()
{
    return this->next;
}

Link * Link::getPrev()
{
    return this->prev;
}

void Link::setNext(Link * next)
{
    this->next = next;
}

void Link::setPrev(Link * prev)
{
    this->prev = prev;
}

////////////TEXTCLASS CLASS/////////////////////////////

TextClass::TextClass()
{
    head = nullptr;
    tail = nullptr;
}

TextClass::~TextClass()
{
    while (!isEmpty())
    {
        removeHead();
    }
}

void TextClass::addHead(char value)
{

    if(head == nullptr)
    {
        head = tail = new Link(value);
    }else
    {
        Link * temp = new Link(value, head, nullptr); //Am I setting temp correctly here
        head->setPrev(temp);
        head = temp;
    }
}

void TextClass::addTail(char value)
{
    if (tail == nullptr)
    {
        head = tail = new Link(value);
    }else
    {
        Link * temp = new Link(value,nullptr,tail);
        tail->setNext(temp);
        tail = temp;
    }
}

char TextClass::getHead()
{
    if(head == nullptr)
    {
        throw out_of_range("Empty List - getHead");
    }
    char head_value = head->getValue();
    return head_value;
}

char TextClass::getTail()
{
    if(head == nullptr)
    {
        throw out_of_range("Empty List - getTail");
    }
    char tail_value = tail->getValue();
    return tail_value;
}

void TextClass::removeHead()
{
    if (head == nullptr)
    {
        throw out_of_range("Empty List - removeHead");
    }
    Link * temp = head;
    head = head->getNext();
    if (head == nullptr)
    {
        tail = nullptr;
    }else
    {
        head->setPrev(nullptr);
    }
    //delete Link * temp;
}

void TextClass::removeTail()
{
    if (tail == nullptr)
    {
        throw out_of_range("List is Empty - removeTail");
    }
    Link * temp = tail;
    tail = tail->getPrev();
    if(tail == nullptr)
    {
        head = nullptr;
    }else
    {
        tail->setNext(nullptr);
    }
    delete temp;
}
bool TextClass::find(char value)
{
    bool found = false;
    Link * ptr = head;
    while(ptr != nullptr)
    {
        if(value == ptr->getValue())
        {
            found = true;
            ptr = nullptr;
        }else
        {
            ptr = ptr->getNext();
        }
    }
    return found;
}
bool TextClass::findRemove(char value)
{
    Link * ptr = head;
    while(ptr != nullptr)
    {
        if(ptr->getValue() == value)
        {
            if (ptr == head)
            {
                removeHead();
                return true;
            }
            if (ptr == tail)
            {
                removeTail();
                return true;
            }
            ptr->getPrev()->setNext(ptr->getNext());
            ptr->getNext()->setPrev(ptr->getPrev());
            delete ptr;
            return true;
        }else
        {
            ptr = ptr->getNext();
        }
    }
    return false;
}

string TextClass::displayList()
{
    string list;
    Link * ptr = head;
    while (ptr != nullptr)
    {
        list += ptr->getValue();
        list += " ";
        ptr = ptr->getNext();
    }
    return list;
}

bool TextClass::isEmpty()
{
    return (head == nullptr);
}

void TextClass::append(TextClass const & other_list)
{
    Link * ptr = other_list.head;

    while(ptr != nullptr)
    {
        addTail(ptr->getValue());
        ptr = ptr->getNext();
    }
}

bool TextClass::findNext(char value)
{
    bool found = false;
    Link * ptr = head;
    while(ptr != nullptr)
    {
        if(value == ptr->getValue() && (ptr != dupe_location))
        {
            found = true;
            dupe_location = ptr;
            ptr = nullptr;
        }else
        {
            ptr = ptr->getNext();
        }
    }
    return found;
}

void TextClass::removeLast()
{
    if(dupe_location != nullptr)
    {
        dupe_location->getPrev()->setNext(dupe_location->getNext());
        dupe_location->getNext()->setPrev(dupe_location->getPrev());
        delete dupe_location;
        dupe_location = nullptr;
    }
}

void TextClass::insertLast(char value)
{
    if(dupe_location != nullptr)
    {
        Link * temp = new Link(value,dupe_location,dupe_location->getPrev());
        (dupe_location->getPrev())->setNext(temp);
        dupe_location->setPrev(temp);
    }
}













