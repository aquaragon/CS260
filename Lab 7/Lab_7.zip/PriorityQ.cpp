//
// Created by Aiden on 5/17/2022.
//

#include "PriorityQ.hpp"
#include <stdexcept>

PriorityQ::PriorityQ(int n)
{
    if(n > DEF_ARRAY_SIZE)
    {
        array_size = n;
        pQueue_array = new int [array_size];
    }else
    {
        array_size = DEF_ARRAY_SIZE;
        pQueue_array = new int [array_size];
    }
}

PriorityQ::~PriorityQ()
{
    delete [] pQueue_array;
}

void PriorityQ::resize()
{
    int * doubled_array = new int [array_size * 2];
    for(int i = 0; i < array_size; i++)
    {
        doubled_array[i] = pQueue_array[i];
    }
    delete [] pQueue_array;
    pQueue_array = doubled_array;
    array_size *= 2;
}

void PriorityQ::BubbleUp(int child)
{
    int parent = (child - 1)/2;
    while(child > 0 && pQueue_array[parent] > pQueue_array[child])
    {
        int temp = pQueue_array[parent];
        pQueue_array[parent] = pQueue_array[child];
        pQueue_array[child] = temp;
        child = parent;
        parent = (child -1)/2;
    }
}

void PriorityQ::addItem(int item)
{
    if(count >= array_size)
    {
        resize();
    }
    pQueue_array[count] = item;
    count++;
    if(count - 1 != 0)
    {
        BubbleUp(count - 1);
    }
}

void PriorityQ::trickleDown(int root)
{
    do{
        int j = -1;
        int right = 2*root + 2;
        if(right < count && pQueue_array[right] < pQueue_array[root])
        {
            int left = 2*root + 1;
            if(pQueue_array[left] < pQueue_array[right])
            {
                j = left;
            }else
            {
                j = right;
            }
        }else
        {
            int left = 2*root +1;
            if(left < count && pQueue_array[left] < pQueue_array[root])
            {
                j = left;
            }
        }
        if(j >= 0)
        {
            int temp = pQueue_array[root];
            pQueue_array[root] = pQueue_array[j];
            pQueue_array[j] = temp;
        }
        root = j;
    }while(root >= 0);
}

int PriorityQ::getItem()
{
    if (count == 0)
    {
        throw std::out_of_range("Empty Array");
    }
    int smallest = pQueue_array[0];
    pQueue_array[0] = pQueue_array[--count];
    trickleDown(0);
    return smallest;
}