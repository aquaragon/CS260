//
// Created by Aiden on 5/9/2022.
//

#ifndef LAB_6_TREE_HPP
#define LAB_6_TREE_HPP

//
// Created by aiden on 4/28/2022.
//

#ifndef LAB_5_PARSETREE_HPP
#define LAB_5_PARSETREE_HPP

#include <string>

using std::string;

struct Node
{
    int value;
    Node * left;
    Node * right;
    bool present;
    Node(int value): value(value), left(nullptr), right(nullptr), present(true){};
    ~Node() = default;
};

class Tree
{
private:
    Node * remove_location = nullptr;
    Node * root;
public:
    Tree();
    ~Tree();
    void recDelete(Node * ptr);
    void insertValue(int value);
    bool findValue(int value);
    bool recFindvalue(int value, Node * ptr);
    string inOrder();
    string recInOrder(Node * ptr);
    string preOrder();
    string recPreOrder(Node * ptr);
    string postOrder();
    string recPostOrder(Node * ptr);
    bool removeValue(int value);
    int findLarger(int value);
    int removeLarger(int value);
};


#endif //LAB_5_PARSETREE_HPP


#endif //LAB_6_TREE_HPP
